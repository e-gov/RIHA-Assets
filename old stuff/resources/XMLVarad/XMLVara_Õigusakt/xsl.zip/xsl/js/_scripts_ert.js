
/* JS
-------------------------------------------------- */
document.getElementsByTagName("html")[0].className = "js";

/* wrapToggle */

var wrapToggle = {
	init : function(){
		$("#toggle-laws").children("a").click(this.clickIt);
	},
	clickIt : function(){
		var cont = $(this).parent();
		var wrap = cont.next("div.wrap");
		var span = $(this).children("span");

		wrap.toggleClass("wrap-closed");
		cont.toggleClass("toggle-laws-closed");
		if(cont.is(".toggle-laws-closed")){
			span.text(span.data("text").closed);
		} else {
			span.text(span.data("text").open);
		}
		return false;
	}
};

function fixIEoverflow() {
	if (!/*@cc_on!@*/0) return;

	var all = document.getElementsByTagName('*'), i = all.length;
	while (i--) {
		// adding a class match just to show the difference
		if (all[i].className.match(/scroll/) && all[i].scrollWidth > all[i].offsetWidth) {
			all[i].style['overflowY'] = 'hidden';
			all[i].style['paddingBottom'] = '17px';
		}
	}
}

$(function(){
	wrapToggle.init();
//	dropList.init();
//	contentsShow.init();
});